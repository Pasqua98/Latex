function [KP,KI,KD,T_l] = PIDdesign(P,w_gc,phi_m,alpha,type)
beta=2;
resp=freqresp(P,w_gc);
k=1/abs(resp);
phi=-pi+phi_m-angle(resp);
KP=k*cos(phi);
KI=0;
KD=0;
T_l=1e-6; %needed to avoid errors
if strcmp(type,"PID")
    TD=(tan(phi)+sqrt((tan(phi)^2+(4/alpha))))/(2*w_gc);
    TI=alpha*TD;
    KD=TD*KP;
    KI=KP/TI;
    T_l=1/(w_gc*beta);
elseif strcmp(type,"PI")
    KI=-w_gc*k*sin(phi);
elseif strcmp(type,"P")

elseif strcmp(type,"PD")
    KD=(k*sin(phi))/(w_gc);
    T_l=1/(w_gc*beta);
else
    error("Type of controller not adequate");
end
end